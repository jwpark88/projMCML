rm(list=ls())
# need to specify your directory 
source("poiDiscreteMCMLsource.R")

##### Simulate the count data #####
library(ngspatial)
library(MASS)

set.seed(3)
# Use the 30 x 30 square lattice as the underlying graph.
n = 30
A = adjacency.matrix(n)
Q = diag(rowSums(A),n^2) - A

# Assign coordinates to each vertex such that the coordinates are restricted to the unit square
# centered at the origin.
x = rep(0:(n - 1) / (n - 1), times = n) 
y = rep(0:(n - 1) / (n - 1), each = n) 
X = cbind(x, y)                                 # Use the vertex locations as spatial covariates.
beta = c(1, 1)                                  # These are the regression coefficients.

# Dimension reduction step based on evls
P.perp = diag(1,n^2) - X%*%solve(t(X)%*%X)%*%t(X)
eig = eigen(P.perp %*% A %*% P.perp)
eigenvalues = eig$values
# plot(eigenvalues)  # choose only 400 evls. 
q=400

M = eig$vectors[,c(1:q)]
Q.s = t(M) %*% Q %*% M

# simulate the true data 
tau = 6
Inv.Sigma = solve(tau*Q.s)
delta.s = mvrnorm(1, rep(0,q), Inv.Sigma)
lambda = exp( X%*%beta + M%*%delta.s )
Z = c()
for(i in 1:n^2){Z[i] = rpois(1,lambda[i])}


# tuning for running algorithms 
linmod <- glm(Z~X-1,family="poisson") # Find starting values
starting <- list("beta"=coef(linmod),"tau"=1/var(linmod$residuals)) 
starting 

tuning   <- list("beta"=c(sqrt(diag(vcov(linmod)))),"tau"=0.1,"w"=0.1) # set tuning parameters
outerstop <- c("epsilon" = 0.5,"maxouter"=40)    # stopping rule of outer loops
maxiter1 = 2e4; essCriteria1=3                   # stopping rule for finding importance function
maxiter2 = 1e5; essCriteria2=20                  # stopping rule for MCMLE at last iteration

stopping = c("maxiter" = maxiter2,"essCriteria"=essCriteria2)

# fitting MCML
set.seed(2)
result = poi_gmrf_pSeqMCML(O=Z, X, A, maxiter1, essCriteria1, maxiter2, essCriteria2, outerstop = outerstop, starting=starting, tuning=tuning, rank = 50)
tau = result$tau
beta = result$beta
TAU = result$TAU
BETA = result$BETA
LIK = result$LIK
se = result$se
mcse = result$mcse
