## 1. To implement this code, you need to install the following R packages. 

fields
Rcpp
RcppArmadillo
mvtnorm
mgcv
MASS

## 2. Source code 
All the soucce code/data sets are located in the "source" folder. 

## 3. Run code 

## poiMCMLrank: this code is for the Poisson simulation under the continuous domain
## binaryMCMLrank: this code is for the binary simulation under the continuous domain 
## poiDiscreteMCMLrank: this code is for Poisson simulation under the discrete domain
## mistletoeLarge: this code is for fitting the binary mistletoe data set
## Infant: this code is for fitting the infant mortality data set