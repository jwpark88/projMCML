rm(list=ls())
library(fields)
library(Rcpp)
library(RcppArmadillo)
library(mvtnorm)
library(mgcv)
library(MASS)

#####   Call C++ functions   #####
sourceCpp("rp.cpp")  # I made C function in the .cpp file. 
source("http://www.stat.psu.edu/~mharan/batchmeans.R")

ess = function(outp,imselags=TRUE)
  {
    if (imselags) # truncate number of lags based on imse approach
      {
        chainACov <- acf(outp,type="covariance",plot = FALSE)$acf ## USE AUTOCOVARIANCES
        ACovlen <- length(chainACov)
        gammaACov <- chainACov[1:(ACovlen-1)]+chainACov[2:ACovlen]
        
        m <- 1
        currgamma <- gammaACov[1]
        k <- 1
        while ((k<length(gammaACov)) && (gammaACov[k+1]>0) && (gammaACov[k]>=gammaACov[k+1]))
          k <- k +1
        if (k==length(gammaACov)) # added up until the very last computed autocovariance
        chainACorr = acf(outp,type="correlation",plot = FALSE)$acf ## USE AUTOCORRELATIONS
        if (k==1)
          ACtime = 1
        else
          ACtime <- 1 + 2*sum(chainACorr[2:k])  # add autocorrelations up to lag determined by imse
      }
    else
      {
        chainACorr = acf(outp,type="correlation",plot = FALSE)$acf ## USE AUTOCORRELATIONS
        ACtime <- 1 + 2*sum(chainACorr[-c(1)])
      }
    
    return(length(outp)/ACtime)
  }


# define covariance function
covfndef <- function(nu){
  # exponential 
  if(nu == 1/2) covfn <- function(dist,phi) { 
    K = exp(-1/phi*dist) 
    return(K)
  }
  # matern 1.5
  if(nu == 1.5) covfn <- function(dist,phi) { 
    K = (1+sqrt(3)/phi*dist)*exp(-sqrt(3)/phi*dist)
    return(K)
  }
  # matern 1.5
  if(nu == 2.5 ) covfn <- function(dist,phi) { 
    K = (1+sqrt(5)/phi*dist+ 5/(3*phi^2)*dist^2)*exp(-sqrt(5)/phi*dist)
    return(K)
  }
  # square exponential
  if(nu ==10) covfn <- function(dist,phi) { 
    K = exp(-1/(2*phi^2)*dist^2) 
    return(K)
  }
  return(covfn)
}


plotRef <- function(spatialdata, vals,...){
       library(sp)
       library(gstat)
       library(nlme)
       library(fields)
       library(classInt)
       library(maps)

       pal <- tim.colors(8)
       ints <- classIntervals(vals, n = 8, style = "pretty") # Determine breakpoints
       intcols <- findColours(ints, pal) # vector of colors

       plot(spatialdata, col = intcols, pch = 19,xlab="",ylab="")
}

legend.col <- function(col, lev){
          opar <- par
          n <- length(col)           
          bx <- par("usr")
 
          box.cx <- c(bx[2] + (bx[2] - bx[1]) / 1000,
          bx[2] + (bx[2] - bx[1]) / 1000 + (bx[2] - bx[1]) / 50)
          box.cy <- c(bx[3], bx[3])
          box.sy <- (bx[4] - bx[3]) / n
 
          xx <- rep(box.cx, each = 2)
 
          par(xpd = TRUE)
          for(i in 1:n){
          yy <- c(box.cy[1] + (box.sy * (i - 1)),
          box.cy[1] + (box.sy * (i)),          
          box.cy[1] + (box.sy * (i)),
          box.cy[1] + (box.sy * (i - 1)))
          polygon(xx, yy, col = col[i], border = col[i])           
          }
          par(new = TRUE)
          plot(0, 0, type = "n",
          ylim = c(min(lev), max(lev)),
          yaxt = "n", ylab = "",
          xaxt = "n", xlab = "",
          frame.plot = FALSE)
          axis(side = 4, las = 2, tick = FALSE, line = .25)
          par <- opar
          }

##########   Step 1. Conditional Simulation for a generalised linear spatial model ##########   
##########                    This part is matched to glsm.mcmc function           ########## 

binary_gp_rpIS <- function(O=obs,coords=coords,X, covfn = covfn, stopping=stopping,nu=nu, starting=starting, tuning=tuning, rank = rk,mul=2){
  ptm <- proc.time()  
  p = ncol(X) 
  n <-length(O)
  rk = rank*mul
  essCriteria=stopping[["essCriteria"]]; maxiter = stopping[["maxiter"]]
 
  # log full conditional of delta
  delta.lf<-function(delta){ # delta is rank-m
    w = U %*% (sqrt(d)*delta) # d = D^2 from random projection
    z <- xbeta + w # U is from random projection 
    foo2 <- crossprod(delta,delta) 
    lf <- -sum(log(1+exp((1-2*O)*z))) - 1/(2*sParams[s2indx]) * foo2
    return(list(lr=lf,twKinvw=foo2,w = w))
  }

  # define index for parameters
  nParams <- p+2;  betaindx <- 1:p;  s2indx <- p+1;  phiindx <- s2indx+1

  # initialize some matrix for storage
  samples_eta <- matrix(0,ncol=rank,nrow=maxiter)     # store the r.e samples
  samples_w <- matrix(0,ncol=n,nrow=maxiter)          # store the W samples
  sTunings <- sParams <- matrix(NA,nrow=nParams) # update the current parameters for each iteration

  # feed in the initial values and tuning params
  sParams[betaindx] <- starting[["beta"]];  sParams[s2indx] <- starting[["s2"]];  sParams[phiindx] <- starting[["phi"]]
  sTunings[betaindx] <- tuning[["beta"]];  sTunings[s2indx] <- tuning[["s2"]];  sTunings[phiindx] <- tuning[["phi"]]
  wTunings <- rep(tuning[["w"]],rank)
  wTunings <-log(wTunings)
  sTunings <- log(sTunings)
    
  # call c function to approximate eigenvalues and vectors
  CovMat = covfn(dist,sParams[phiindx])   
  K.rp <-  rp(n,rk,alpha=1,CovMat,rank)  # C++ function for approximating eigenvectors
  
  U1 <- U <- K.rp$u[,1:rank] # approximate eigenvectors
  d <- (K.rp$d[1:rank])^2 #approximate eigenvalues 
  xbeta<-X%*%sParams[betaindx]
  
  if (is.null(starting[["w"]])){
    etaParams <- rep(0,rank)
    wParams <- U%*%(sqrt(d)*etaParams)
  }else{
    wParams <- starting[["w"]]
    etaParams <- 1/sqrt(d)*(t(U)%*%wParams)
  }
  samples_w[1,] = wParams; samples_eta[1,] = etaParams
  if(!is.null(starting[["COV"]])){ COV = starting$COV}

  ##### start MCMC loop #####
  i = 0; ESS = 0 
  while( (ESS <  essCriteria*rank) &  (i < maxiter) ){
      i = i + 1 
      if( i%%1000==0 ){ ESS = ess(samples_eta[1:(i-1),1],imselags=FALSE) }
      # update random effects using multivariate random walk with spherical normal proposal
      #if(is.null(starting[["COV"]])){
         deltastar <- rnorm(rank,etaParams,exp(wTunings))      
      #}else{
      #   deltastar <- mvrnorm(1,mu=etaParams,COV)      
      #} 

      delta.lfcand <- delta.lf(deltastar)
      delta.lfcur<- delta.lf(etaParams)
      lr <- delta.lfcand$lr - delta.lfcur$lr
      
      if(log(runif(1)) < lr) {
        etaParams <- deltastar
        delta.lfcur <- delta.lfcand
        wParams <- delta.lfcur$w
      }
      
      samples_w[i,] <- wParams
      samples_eta[i,] <- etaParams
  }
  samples_w = samples_w[1:i,]
  samples_eta = samples_eta[1:i,]

  cat("MCMC chain size:", i,"\n")  
  runtime=proc.time() - ptm
  cat("runtime", "\n")  
  print(runtime)
  
  return(list(run.time=runtime, starting = starting, nu = nu, X=X, O=O, rank=rank, eta.params = samples_eta, w.params = samples_w, U =U, d= d))
  
}



##########            Step 2. Monte Carlo Maximum Likelihood estimate              ##########   
#########    This part is matched to prepare.likfit.glsm/likfit.glsm function      ########## 

# Fast search
binary_gp_rpLikfast <- function(mcmc.output){
  ptm <- proc.time()  
  
  eta <- mcmc.output$eta.params; w <- mcmc.output$w.params
  burnin <- dim(eta)[1]/10
  thin <- 30

  eta <- eta[(burnin+1):dim(eta)[1],]
  w <- w[(burnin+1):dim(w)[1],]
  eta <- eta[  thin*(1:round(dim(eta)[1]/thin)),  ]
  w <- w[  thin*(1:round(dim(w)[1]/thin)),  ]
  numiter <- dim(eta)[1]

  U <- U1 <- mcmc.output$U 
  d <- mcmc.output$d
  rank <- mcmc.output$rank
  rk <- rank*2
  starting <- mcmc.output$starting 
  
  O <- mcmc.output$O
  X <- mcmc.output$X
  n <- dim(X)[1]; p <- dim(X)[2]
  nu <- mcmc.output$nu

  # necessary precomputation
  eta.eta = eta%*%t(eta) 
  U.Dhalf.eta = U%*%(sqrt(d)*t(eta)) 

  # likelihood evaluation using random effect samples / starting beta, phi, sigmasq
  # log[ f(Z|beta,U,D,delta)f(delta|theta) ] 
  beta = starting$beta
  xbeta<-X%*%beta
  sigmasq = starting$s2
  
  log.f.sim <- c()
  for(i in 1:numiter){
      z <- U%*%(sqrt(d)*eta[i,]) + xbeta
      log.f.sim[i] = -sum(log(1+exp((1-2*O)*z))) - 1/(2*sigmasq)*eta.eta[i,i] -(rank/2)*log(sigmasq) 
      }


  # log[ f(Z|beta,U,D,delta)f(delta|theta) ] 
  func.val <- function(U.Dhalf.eta, beta,sigmasq){

            # necessary precomputation
            xbeta = X%*%beta
            z = matrix(rep(xbeta,numiter),numiter,byrow=T)  +  t(U.Dhalf.eta)

            # likelihood evaluation using random effect samples / beta, phi, sigmasq
            # log[ f(Z|beta,U,D,delta)f(delta|theta) ] 
            log.f <- c()
            for(i in 1:numiter){ log.f[i] = -sum(log(1+exp((1-2*O)*z[i,]))) - 1/(2*sigmasq)*eta.eta[i,i] -(rank/2)*log(sigmasq) }
            
            return(log.f)
            }

  # newton raphson function for obtaining MLE of beta and sigmasq for given phi
  newton <- function(beta,sigmasq, U.Dhalf.eta, steplen){

    # necessary precomputation
    xbeta = X%*%beta
    # z <- U%*%(sqrt(d)*eta[i,]) + xbeta
    z = matrix(rep(xbeta,numiter),numiter,byrow=T)  +  t(U.Dhalf.eta)
    prob = exp(z)/(1+exp(z))
    E = prob; V = prob*(1-prob)

    # log[ f(Z|beta,U,D,delta)f(delta|theta) ] for given previous beta and sigmasq
    log.f = func.val(U.Dhalf.eta,beta,sigmasq)

    # weight evaluation 
    dummy = log.f - log.f.sim
    mx = max(dummy)
    weight = exp(log.f - log.f.sim - mx)/sum( exp(log.f - log.f.sim - mx)  )

    # first and second derivatives for beta and sigmasq
    log.gradbeta = t(X)%*%t( matrix(rep(Z,numiter),numiter,byrow=T) - E )  
    log.gradbeta2 = -t(X)%*%(diag(n)*apply(V*weight,2,sum))%*%X
    log.gradsigmasq = -(rank/(2*sigmasq)) + (1/(2*sigmasq^2))*diag(eta.eta)
    log.gradsigmasq2 = (rank/(2*sigmasq^2)) - (1/(sigmasq^3))*diag(eta.eta)

    # first and second derivative of MCML likelihood 
    grad1 = cbind( t(log.gradbeta), log.gradsigmasq)
    grad2.part1 = rbind( cbind(log.gradbeta2,0), c(rep(0,dim(log.gradbeta2)[1]),sum(log.gradsigmasq2*weight)) )
    grad2.part2 = 0

    GRAD1 = apply(grad1*weight,2,sum)
    dummy = grad1 - matrix(rep(GRAD1,numiter),numiter,byrow=T)
    for(i in 1:numiter){ grad2.part2 = grad2.part2 + dummy[i,]%*%t(dummy[i,])*weight[i] }
    GRAD2 = grad2.part1 + grad2.part2

    par.prev = c(beta,sigmasq)
    # for numerical stability
     if( (abs(det(GRAD2)) < 1e-5) ){ par.next = par.prev }else{
     par.next = par.prev - steplen*t(GRAD1)%*%solve(GRAD2) }
     if(  par.next[p+1] < 0 ){ par.next = par.prev }
     return(par.next = par.next)
   }



  ### Step 1. Obtain MLE for beta and sigma for given phi
  # this part is matched to maxim.aux1 
  
  # MLE of beta and sigmasq for given phi
  i = 0
  test <- test2 <- 1
  steplen <- 1
  curr = prev = c(starting$beta,median( diag(eta.eta)/rank ))

  log.f = func.val(U.Dhalf.eta, prev[1:p], prev[p+1])
  dummy = log.f - log.f.sim
  mx = max(dummy)
  log.lik.prev  = log(mean(  exp(dummy-mx)  )) + mx

  while(test>0.0000000000001  | test2 > 0 ){
    i = i + 1
    # newton raphson update
    curr = newton(prev[1:p],prev[p+1],U.Dhalf.eta,steplen)
    
    # likelihood for given updated parameters
    log.f = func.val(U.Dhalf.eta,curr[1:p],curr[p+1])
    dummy = log.f - log.f.sim
    mx = max(dummy)
    log.lik.next  = log(mean(  exp(dummy-mx)  )) + mx

    test2 = log.lik.next - log.lik.prev
    test <- sum( (prev- curr)^2 )

    if(test2 >0){
       log.lik.prev <- log.lik.next
       prev <- curr
       }else{ steplen <- steplen/2}
  }
  beta = curr[1:p]; sigmasq = curr[p+1]
  

  ### Step 2. Obtain MLE for phi for given mle of beta and sigma 
  # this part is matched to .lik.sim
  # MCML(phi)
  loglik.mcml <- function(phi){
    
    CovMat = covfn(dist,phi)   
    K.rp <-  rp(n,rk,alpha=1,CovMat,rank)  # C++ function for approximating eigenvectors
    d <- (K.rp$d[1:rank])^2 # approximated eigenvalues 
    U <- K.rp$u[,1:rank]
    
    signdiag = sign(diag(t(U)%*%U1)) # find the sign change
    signdiag = as.logical(1-signdiag)
    U[,signdiag] = -U[,signdiag]
    
    ###############################################
    ###  For given phi, update beta, sigmasq, log.lik ###
    # this part is matched to maxim.aux1 
    U.Dhalf.eta = U%*%(sqrt(d)*t(eta)) 
 
    # log[ f(Z|beta,U,D,delta)f(delta|theta) ] 
    log.f = func.val(U.Dhalf.eta,beta,sigmasq)
    dummy = log.f - log.f.sim
    mx = max(dummy)
    log.lik  = log(mean(  exp(dummy-mx)  )) + mx
    ################################################
    ###  evaluate loglikelihood for given phi, beta, sigmasq  ###
    loglik = log.lik 
    return(-loglik)
  }

  #Instead of optimization find neighboring values which maximize likelhiood (grid search)
  phi.seq <- seq( starting$phi - 0.2*starting$phi, starting$phi + 0.2*starting$phi, length = 10)
  phi.lik <- c()
  for(i in 1:10){ phi.lik[i] = loglik.mcml(phi.seq[i]) }
  # likelihood should be increased
  if( max(-phi.lik) > 0 ){ phi.hat <-phi.seq[which.max( -phi.lik )] }else{ phi.hat <- starting$phi }
  
  phi <- phi.hat

  # logliklihood for given MLE 
   log.lik = -phi.lik[which.max( -phi.lik )]

  runtime=proc.time() - ptm
  cat("runtime", "\n")  
  print(runtime)
  return(list(beta = beta, sigmasq = sigmasq, phi = phi, log.lik = log.lik))
}


# Final optimization
binary_gp_rpLikfit <- function(mcmc.output){
  ptm <- proc.time()  
  
  eta <- mcmc.output$eta.params; w <- mcmc.output$w.params
  burnin <- dim(eta)[1]/10
  thin <- 30

  eta <- eta[(burnin+1):dim(eta)[1],]
  w <- w[(burnin+1):dim(w)[1],]
  eta <- eta[  thin*(1:round(dim(eta)[1]/thin)),  ]
  w <- w[  thin*(1:round(dim(w)[1]/thin)),  ]
  numiter <- dim(eta)[1]


  U <- U1 <- mcmc.output$U 
  d <- mcmc.output$d
  rank <- mcmc.output$rank
  rk <- rank*2
  starting <- mcmc.output$starting 
  
  O <- mcmc.output$O
  X <- mcmc.output$X
  n <- dim(X)[1]; p <- dim(X)[2]
  nu <- mcmc.output$nu

  # necessary precomputation
  eta.eta = eta%*%t(eta) 
  U.Dhalf.eta = U%*%(sqrt(d)*t(eta)) 

  # likelihood evaluation using random effect samples / starting beta, phi, sigmasq
  # log[ f(Z|beta,U,D,delta)f(delta|theta) ] 
  beta = starting$beta
  xbeta<-X%*%beta
  sigmasq = starting$s2
  
  log.f.sim <- c()
  for(i in 1:numiter){
      z <- U%*%(sqrt(d)*eta[i,]) + xbeta
      log.f.sim[i] = -sum(log(1+exp((1-2*O)*z))) - 1/(2*sigmasq)*eta.eta[i,i] -(rank/2)*log(sigmasq) 
      }

  # log[ f(Z|beta,U,D,delta)f(delta|theta) ] 
  func.val <- function(U.Dhalf.eta, beta,sigmasq){

            # necessary precomputation
            xbeta = X%*%beta
            z = matrix(rep(xbeta,numiter),numiter,byrow=T)  +  t(U.Dhalf.eta)

            # likelihood evaluation using random effect samples / beta, phi, sigmasq
            # log[ f(Z|beta,U,D,delta)f(delta|theta) ] 
            log.f <- c()
            for(i in 1:numiter){ log.f[i] = -sum(log(1+exp((1-2*O)*z[i,]))) - 1/(2*sigmasq)*eta.eta[i,i] -(rank/2)*log(sigmasq) }
            
            return(log.f)
            }

  # newton raphson function for obtaining MLE of beta and sigmasq for given phi
  newton <- function(beta,sigmasq, U.Dhalf.eta, steplen){

    # necessary precomputation
    xbeta = X%*%beta
    # z <- U%*%(sqrt(d)*eta[i,]) + xbeta
    z = matrix(rep(xbeta,numiter),numiter,byrow=T)  +  t(U.Dhalf.eta)
    prob = exp(z)/(1+exp(z))
    E = prob; V = prob*(1-prob)

    # log[ f(Z|beta,U,D,delta)f(delta|theta) ] for given previous beta and sigmasq
    log.f = func.val(U.Dhalf.eta,beta,sigmasq)

    # weight evaluation 
    dummy = log.f - log.f.sim
    mx = max(dummy)
    weight = exp(log.f - log.f.sim - mx)/sum( exp(log.f - log.f.sim - mx)  )

    # first and second derivatives for beta and sigmasq
    log.gradbeta = t(X)%*%t( matrix(rep(Z,numiter),numiter,byrow=T) - E )  
    log.gradbeta2 = -t(X)%*%(diag(n)*apply(V*weight,2,sum))%*%X
    log.gradsigmasq = -(rank/(2*sigmasq)) + (1/(2*sigmasq^2))*diag(eta.eta)
    log.gradsigmasq2 = (rank/(2*sigmasq^2)) - (1/(sigmasq^3))*diag(eta.eta)

    # first and second derivative of MCML likelihood 
    grad1 = cbind( t(log.gradbeta), log.gradsigmasq)
    grad2.part1 = rbind( cbind(log.gradbeta2,0), c(rep(0,dim(log.gradbeta2)[1]),sum(log.gradsigmasq2*weight)) )
    grad2.part2 = 0

    GRAD1 = apply(grad1*weight,2,sum)
    dummy = grad1 - matrix(rep(GRAD1,numiter),numiter,byrow=T)
    for(i in 1:numiter){ grad2.part2 = grad2.part2 + dummy[i,]%*%t(dummy[i,])*weight[i] }
    GRAD2 = grad2.part1 + grad2.part2

    par.prev = c(beta,sigmasq)
    # for numerical stability
     if( (abs(det(GRAD2)) < 1e-5) ){ par.next = par.prev }else{
     par.next = par.prev - steplen*t(GRAD1)%*%solve(GRAD2) }
     if(  par.next[p+1] < 0 ){ par.next = par.prev }
     return(par.next = par.next)
   }

  ### Step 1. Obtain MLE for beta and sigma for given phi
  # this part is matched to maxim.aux1 
  
  # MLE of beta and sigmasq for given phi
  i = 0
  test <- test2 <- 1
  steplen <- 1
  curr = prev = c(starting$beta,median( diag(eta.eta)/rank ))

  log.f = func.val(U.Dhalf.eta, prev[1:p], prev[p+1])
  dummy = log.f - log.f.sim
  mx = max(dummy)
  log.lik.prev  = log(mean(  exp(dummy-mx)  )) + mx


  while(test>0.0000000000001  | test2 > 0 ){
    i = i + 1
    # newton raphson update
    curr = newton(prev[1:p],prev[p+1],U.Dhalf.eta,steplen)
    
    # likelihood for given updated parameters
    log.f = func.val(U.Dhalf.eta,curr[1:p],curr[p+1])
    dummy = log.f - log.f.sim
    mx = max(dummy)
    log.lik.next  = log(mean(  exp(dummy-mx)  )) + mx

    test2 = log.lik.next - log.lik.prev
    test <- sum( (prev- curr)^2 )

    if(test2 >0){
       log.lik.prev <- log.lik.next
       prev <- curr
       }else{ steplen <- steplen/2}
  }
  beta = curr[1:p]; sigmasq = curr[p+1]

  ### Step 2. Obtain MLE for phi for given mle of beta and sigma 
  # this part is matched to .lik.sim
  # MCML(phi)
  loglik.mcml <- function(phi){
    
    CovMat = covfn(dist,phi)   
    K.rp <-  rp(n,rk,alpha=1,CovMat,rank)  # C++ function for approximating eigenvectors
    d <- (K.rp$d[1:rank])^2 # approximated eigenvalues 
    U <- K.rp$u[,1:rank]
    
    signdiag = sign(diag(t(U)%*%U1)) # find the sign change
    signdiag = as.logical(1-signdiag)
    U[,signdiag] = -U[,signdiag]
    
    ###############################################
    ###  For given phi, update beta, sigmasq, log.lik ###
    # this part is matched to maxim.aux1 
    U.Dhalf.eta = U%*%(sqrt(d)*t(eta)) 
 
    # log[ f(Z|beta,U,D,delta)f(delta|theta) ] 
    log.f = func.val(U.Dhalf.eta,beta,sigmasq)
    dummy = log.f - log.f.sim
    mx = max(dummy)
    log.lik  = log(mean(  exp(dummy-mx)  )) + mx
    ################################################
    ###  evaluate loglikelihood for given phi, beta, sigmasq  ###
    loglik = log.lik 
    return(-loglik)
  }

  #lik.optim <- optim(par = starting$phi, fn = loglik.mcml, method = "Brent", lower = 0, upper = 5*starting$phi)
  lik.optim <- optim(par = starting$phi, fn = loglik.mcml)
  phi.hat <- lik.optim$par
  
  
  ### Step 3. Obtain MLE for beta and sigma for given MLE OF PHI 
  phi = phi.hat
  CovMat = covfn(dist,phi.hat)   
  K.rp <-  rp(n,rk,alpha=1,CovMat,rank)  # C++ function for approximating eigenvectors
  d <- (K.rp$d[1:rank])^2 # approximated eigenvalues 
  U <- K.rp$u[,1:rank]

  signdiag = sign(diag(t(U)%*%U1)) # find the sign change
  signdiag = as.logical(1-signdiag)
  U[,signdiag] = -U[,signdiag]

  # necessary precomputation
  U.Dhalf.eta = U%*%(sqrt(d)*t(eta)) 

  # MLE of beta and sigmasq for given phi
  i = 0
  test <- test2 <- 1
  steplen <- 1
  curr = prev = c(beta,sigmasq)

  log.f = func.val(U.Dhalf.eta, prev[1:p], prev[p+1])
  dummy = log.f - log.f.sim
  mx = max(dummy)
  log.lik.prev  = log(mean(  exp(dummy-mx)  )) + mx

  while(test>0.0000000000001  | test2 > 0 ){
    i = i + 1
    # newton raphson update
    curr = newton(prev[1:p],prev[p+1],U.Dhalf.eta,steplen)
    
    # likelihood for given updated parameters
    log.f = func.val(U.Dhalf.eta,curr[1:p],curr[p+1])
    dummy = log.f - log.f.sim
    mx = max(dummy)
    log.lik.next  = log(mean(  exp(dummy-mx)  )) + mx

    test2 = log.lik.next - log.lik.prev
    test <- sum( (prev- curr)^2 )

    if(test2 >0){
       log.lik.prev <- log.lik.next
       prev <- curr
       }else{ steplen <- steplen/2}
  }
  beta = curr[1:p]; sigmasq = curr[p+1]
  phi <- phi.hat
  
  # logliklihood for given MLE 
  log.f = func.val(U.Dhalf.eta,beta,sigmasq)
  dummy = log.f - log.f.sim
  mx = max(dummy)
  log.lik  = log(mean(  exp(dummy-mx)  )) + mx    

  # Monte Carlo standard error for given MLE
  MCSE <- function(beta,sigmasq, U.Dhalf.eta){

    # necessary precomputation
    xbeta = X%*%beta
    # z <- U%*%(sqrt(d)*eta[i,]) + xbeta
    z = matrix(rep(xbeta,numiter),numiter,byrow=T)  +  t(U.Dhalf.eta)
    prob = exp(z)/(1+exp(z))
    E = prob; V = prob*(1-prob)

    # log[ f(Z|beta,U,D,delta)f(delta|theta) ] for given previous beta and sigmasq
    log.f = func.val(U.Dhalf.eta,beta,sigmasq)

    # weight evaluation 
    dummy = log.f - log.f.sim
    mx = max(dummy)
    weight = exp(log.f - log.f.sim - mx)/sum( exp(log.f - log.f.sim - mx)  )
    # logliklihood for given MLE 
    log.lik  = log(mean(  exp(dummy-mx)  )) + mx  

    # first and second derivatives for beta and sigmasq
    log.gradbeta = t(X)%*%t( matrix(rep(Z,numiter),numiter,byrow=T) - E )  
    log.gradbeta2 = -t(X)%*%(diag(n)*apply(V*weight,2,sum))%*%X
    log.gradsigmasq = -(rank/(2*sigmasq)) + (1/(2*sigmasq^2))*diag(eta.eta)
    log.gradsigmasq2 = (rank/(2*sigmasq^2)) - (1/(sigmasq^3))*diag(eta.eta)

    # first and second derivative of MCML likelihood 
    grad1 = cbind( t(log.gradbeta), log.gradsigmasq)
    grad2.part1 = rbind( cbind(log.gradbeta2,0), c(rep(0,dim(log.gradbeta2)[1]),sum(log.gradsigmasq2*weight)) )
    grad2.part2 = 0

    GRAD1 = apply(grad1*weight,2,sum)
    dummy = grad1 - matrix(rep(GRAD1,numiter),numiter,byrow=T)
    for(i in 1:numiter){ grad2.part2 = grad2.part2 + dummy[i,]%*%t(dummy[i,])*weight[i] }
    GRAD2 = grad2.part1 + grad2.part2

    # for numerical stability
    if( (abs(det(GRAD2)) < 1e-5) ){ se = rep(NA,p+1); mcse = rep(NA,p+1) }else{    
    # Sampling error 
    Uhat = GRAD2
    se  = sqrt(diag(solve(-GRAD2)))

    # Monte Carlo error 
    denom = 0 
    for(i in 1:numiter){ denom = denom +  grad1[i,]%*%t(grad1[i,])*exp( 2*(log.f-log.f.sim) - max( 2*(log.f-log.f.sim) ) )[i] }
    denom = denom*exp( max( 2*(log.f-log.f.sim) ) )
    num = 2*(log( sum( exp(log.f-log.f.sim-max(log.f-log.f.sim)) ) ) + max(log.f-log.f.sim) )
    Vhat = numiter*denom/exp(num)

    mcse = sqrt(  diag( solve(Uhat)%*%Vhat%*%solve(Uhat)   ) )/sqrt(numiter) 
     }
   return(list(se=se, mcse = mcse))
   }
    errors = MCSE(beta,sigmasq, U.Dhalf.eta)
   se = errors$se; mcse = errors$mcse

  runtime=proc.time() - ptm
  cat("runtime", "\n")  
  print(runtime)
  return(list(beta = beta, sigmasq = sigmasq, phi = phi, log.lik = log.lik, se = se, mcse = mcse))
}

##########   Step 3. Sequential MCML with stopping criteria ##########   

binary_gp_rpSeqMCML <- function(O=obs,coords=coords,X, covfn = covfn, maxiter1, essCriteria1, maxiter2, essCriteria2, outerstop = outerstop, nu=nu, starting=starting, tuning=tuning, rank = rank, mul=mul){

  ptm <- proc.time()
  p = dim(X)[2]
  epsilon=outerstop[["epsilon"]]; maxouter = outerstop[["maxouter"]]

  stopping1 = c("maxiter" = maxiter1,"essCriteria"=essCriteria1)
  stopping2 = c("maxiter" = maxiter2,"essCriteria"=essCriteria2)

  i = 0; bound = 100; burnin = 15
  BETA = matrix(NA,maxouter,p)
  SIGMASQ = rep(NA,maxouter)
  PHI = rep(NA,maxouter)
  LIK = rep(NA,maxouter)
  
  while( (bound >  epsilon) &  (i < maxouter) ){

      i = i + 1
      print(i)
      # fast search of importance function  
      mcmc.output  = binary_gp_rpIS(O=Z, coords=coords, X=X, covfn=covfn, stopping = stopping1, nu=nu, starting=starting, tuning=tuning, rank=rank, mul=mul)
      res = binary_gp_rpLikfast(mcmc.output) 

      LIK[i] = res$log.lik
      BETA[i,] = res$beta
      SIGMASQ[i] = res$sigmasq
      PHI[i] = res$phi
 
      # update importance function 
      starting$beta = res$beta
      starting$s2 = res$sigmasq
      starting$phi = res$phi
      starting$w = mcmc.output$w.params[dim( mcmc.output$w.params )[1],]

      if( (i >= 10+burnin ) ){  bound = bm(LIK[burnin:i])$est + bm(LIK[burnin:i])$se*qnorm(1-0.05) } 
      }


  # Conduct MCML with good importance function
  mcmc.output  = binary_gp_rpIS(Z, coords=coords, X=X, covfn=covfn, stopping = stopping2, nu=nu, starting=starting, tuning=tuning, rank=rank, mul=mul)
  res = binary_gp_rpLikfit(mcmc.output) 
  runtime = proc.time() - ptm
  cat("runtime", "\n")  
  print(runtime)
  beta = res$beta; sigmasq = res$sigmasq; phi = res$phi; log.lik = res$log.lik; se = res$se;  mcse = res$mcse
  U = mcmc.output$U; d = mcmc.output$d; rank = mcmc.output$rank
  
  return(list(run.time=runtime, eta.params = mcmc.output$eta.params, w.params = mcmc.output$w.params, U=U, d=d, rank=rank, BETA = BETA, SIGMASQ = SIGMASQ, PHI = PHI, LIK = LIK, beta = beta, sigmasq = sigmasq, phi = phi, log.lik= log.lik, se = se, mcse=mcse))
}

# spatial interpolation
gp_rpPrediction <- function(result,coords,preds){
    
    phi = result$phi
    sigmasq = result$sigmasq
    beta = result$beta
    U1 <- result$U;rank = result$rank
    w = result$w.params[dim( result$w.params )[1],]
    
    n = dim(coords)[1];n.pred = dim(preds)[1]
    coords.all<- rbind(coords,preds)
    dist.all <- rdist(coords.all,coords.all) # compute distance matrix
    V.all <- covfn(dist.all,phi) # compute covariance matrix

    pred.V <- V.all[(n+1):(n+n.pred),(n+1):(n+n.pred)]
    pred.coord.V <- V.all[(n+1):(n+n.pred),1:n]

    CovMat = V.all[1:n,1:n]
    K.rp <-  rp(dim(coords)[1],rank*2,alpha=1,CovMat,rank)  # C++ function for approximating eigenvectors
    d <- (K.rp$d[1:rank])^2 # approximated eigenvalues 
    U <- K.rp$u[,1:rank]
    
    signdiag = sign(diag(t(U)%*%U1)) # find the sign change
    signdiag = as.logical(1-signdiag)
    U[,signdiag] = -U[,signdiag]

    # conditional mean and variance for spatial interpolation
    Sigma = sigmasq*(   pred.V -  (1/sigmasq)*pred.coord.V%*%(U%*%diag(1/d)%*%t(U))%*%t(pred.coord.V) )
    Mu = pred.coord.V%*%(U%*%diag(1/d)%*%t(U))%*%w


    out = mvrnorm(1, mu=Mu, Sigma = Sigma)

return(Mu)
}
