
rm(list=ls())
library(fields)
library(Rcpp)
library(RcppArmadillo)
library(mvtnorm)
library(mgcv)
library(MASS)
library(ngspatial)

source("http://www.stat.psu.edu/~mharan/batchmeans.R")

ess = function(outp,imselags=TRUE)
  {
    if (imselags) # truncate number of lags based on imse approach
      {
        chainACov <- acf(outp,type="covariance",plot = FALSE)$acf ## USE AUTOCOVARIANCES
        ACovlen <- length(chainACov)
        gammaACov <- chainACov[1:(ACovlen-1)]+chainACov[2:ACovlen]
        
        m <- 1
        currgamma <- gammaACov[1]
        k <- 1
        while ((k<length(gammaACov)) && (gammaACov[k+1]>0) && (gammaACov[k]>=gammaACov[k+1]))
          k <- k +1
        if (k==length(gammaACov)) # added up until the very last computed autocovariance
        chainACorr = acf(outp,type="correlation",plot = FALSE)$acf ## USE AUTOCORRELATIONS
        if (k==1)
          ACtime = 1
        else
          ACtime <- 1 + 2*sum(chainACorr[2:k])  # add autocorrelations up to lag determined by imse
      }
    else
      {
        chainACorr = acf(outp,type="correlation",plot = FALSE)$acf ## USE AUTOCORRELATIONS
        ACtime <- 1 + 2*sum(chainACorr[-c(1)])
      }
    
    return(length(outp)/ACtime)
  }


##########   Step 1. Conditional Simulation for a generalised linear spatial model ##########   
##########                    This part is matched to glsm.mcmc function           ########## 

poi_gmrf_pIS <- function(O=obs,X,A,stopping=stopping, starting=starting, tuning=tuning, rank = 50){
  ptm <- proc.time()  

  p = ncol(X) 
  n <-length(O)
  essCriteria=stopping[["essCriteria"]]; maxiter = stopping[["maxiter"]]


  P.perp = diag(1,n) - X%*%solve(t(X)%*%X)%*%t(X)
  eig = eigen(P.perp %*% A %*% P.perp)
  eigenvalues = eig$values
  M = eig$vectors[,c(1:rank)]
  Q = diag(rowSums(A),n) - A
  Q.s = t(M) %*% Q %*% M

 
  # need Kinv, updated after phi, 
  delta.lf<-function(delta){ # delta load in eta rank-dimension
    w = M%*%delta
    z <- xbeta + w # U is from random projection 
    foo2 <- t(delta)%*%Q.s%*%delta
    lf <- sum(dpois(O,exp(z),log=T)) - sParams[tauindx]/2* foo2
    return(list(lr=lf,twKinvw=foo2,w = w))
  }
  
  # define index for parameters
  nParams <- p+1;  betaindx <- 1:p;  tauindx <- p+1

  # initialize some matrix for storage
  samples_eta <- matrix(0,ncol=rank,nrow=maxiter)     # store the r.e samples
  samples_w <- matrix(0,ncol=n,nrow=maxiter)          # store the W samples
  sTunings <- sParams <- matrix(NA,nrow=nParams) # update the current parameters for each iteration

  # feed in the initial values and tuning params
  sParams[betaindx] <- starting[["beta"]];  sParams[tauindx] <- starting[["tau"]]
  sTunings[betaindx] <- tuning[["beta"]];  sTunings[tauindx] <- tuning[["tau"]]
  wTunings <- rep(tuning[["w"]],rank)
  wTunings <-log(wTunings)
  sTunings <- log(sTunings)
    
  xbeta<-X%*%sParams[betaindx]
  
  if (is.null(starting[["w"]])){
    etaParams <- rep(0,rank)
    wParams <- M%*%etaParams
  }else{
    wParams <- starting[["w"]]
    etaParams <- t(M)%*%wParams
  }

  samples_w[1,] = wParams; samples_eta[1,] = etaParams
  if(!is.null(starting[["COV"]])){ COV = starting$COV}

  ##### start MCMC loop #####
  i = 0; ESS = 0 
  while( (ESS <  essCriteria*rank) &  (i < maxiter) ){
      i = i + 1 
      if( i%%1000==0 ){ ESS = ess(samples_eta[1:(i-1),1],imselags=FALSE) }
      # update random effects using multivariate random walk with spherical normal proposal
      #if(is.null(starting[["COV"]])){
         deltastar <- rnorm(rank,etaParams,exp(wTunings))      
      #}else{
      #   deltastar <- mvrnorm(1,mu=etaParams,COV)      
      #} 

      delta.lfcand <- delta.lf(deltastar)
      delta.lfcur<- delta.lf(etaParams)
      lr <- delta.lfcand$lr - delta.lfcur$lr
      
      if(log(runif(1)) < lr) {
        etaParams <- deltastar
        delta.lfcur <- delta.lfcand
        wParams <- delta.lfcur$w
      }
      
      samples_w[i,] <- wParams
      samples_eta[i,] <- etaParams
  }
  samples_w = samples_w[1:i,]
  samples_eta = samples_eta[1:i,]

  cat("MCMC chain size:", i,"\n")  
  runtime=proc.time() - ptm
  cat("runtime", "\n")  
  print(runtime)
  
  return(list(run.time=runtime, starting = starting, X=X, A=A, O=O, rank=rank, eta.params = samples_eta, w.params = samples_w))
  
}

##########            Step 2. Monte Carlo Maximum Likelihood estimate              ##########   
#########    This part is matched to prepare.likfit.glsm/likfit.glsm function      ########## 

poi_gmrf_pLikfit <- function(mcmc.output){
  ptm <- proc.time()  
  
  eta <- mcmc.output$eta.params; w <- mcmc.output$w.params
  burnin <- dim(eta)[1]/10
  thin <- 30

  eta <- eta[(burnin+1):dim(eta)[1],]
  w <- w[(burnin+1):dim(w)[1],]
  eta <- eta[  thin*(1:round(dim(eta)[1]/thin)),  ]
  w <- w[  thin*(1:round(dim(w)[1]/thin)),  ]
  numiter <- dim(eta)[1]

  rank <- mcmc.output$rank
  starting <- mcmc.output$starting 
  
  O <- mcmc.output$O
  X <- mcmc.output$X
  A <- mcmc.output$A
  n <- dim(X)[1]; p <- dim(X)[2]

  # necessary precomputation
  P.perp = diag(1,n) - X%*%solve(t(X)%*%X)%*%t(X)
  eig = eigen(P.perp %*% A %*% P.perp)
  eigenvalues = eig$values
  M = eig$vectors[,c(1:rank)]
  Q = diag(rowSums(A),n) - A
  Q.s = t(M) %*% Q %*% M
  M.eta = (M%*%t(eta))

  # likelihood evaluation using random effect samples / starting beta, phi, sigmasq
  # log[ f(Z|beta,U,D,delta)f(delta|theta) ] 
  beta = starting$beta
  xbeta<-X%*%beta
  tau = starting$tau
  
  log.f.sim <- c()
  for(i in 1:numiter){
      z <- M%*%(eta[i,]) + xbeta
      log.f.sim[i] = sum(dpois(O,exp(z),log=T)) - (tau/2)*(t(eta[i,])%*%Q.s%*%eta[i,])  + (rank/2)*log(tau) 
      }


  # log[ f(Z|beta,U,D,delta)f(delta|theta) ] 
  func.val <- function(beta,tau){

            # necessary precomputation
            xbeta = X%*%beta
            z = matrix(rep(xbeta,numiter),numiter,byrow=T)  +  t(M.eta)

            # likelihood evaluation using random effect samples / beta, tau
            # log[ f(Z|beta,U,D,delta)f(delta|theta) ] 
            log.f <- c()
            for(i in 1:numiter){ log.f[i] = sum(dpois(O,exp(z[i,]),log=T)) - (tau/2)*(t(eta[i,])%*%Q.s%*%eta[i,]) + (rank/2)*log(tau) }
            
            return(log.f)
            }

  # newton raphson function for obtaining MLE of beta and sigmasq for given phi
  newton <- function(beta,tau,steplen){

    # necessary precomputation
    xbeta = X%*%beta
    # z <- U%*%(sqrt(d)*eta[i,]) + xbeta
    z = matrix(rep(xbeta,numiter),numiter,byrow=T)  +  t(M.eta)
    E = V = exp(z)


    # log[ f(Z|beta,U,D,delta)f(delta|theta) ] for given previous beta and sigmasq
    log.f = func.val(beta,tau)

    # weight evaluation 
    dummy = log.f - log.f.sim
    mx = max(dummy)
    weight = exp(log.f - log.f.sim - mx)/sum( exp(log.f - log.f.sim - mx)  )

    # first and second derivatives for beta and sigmasq
    log.gradbeta = t(X)%*%t( matrix(rep(Z,numiter),numiter,byrow=T) - E )  
    log.gradbeta2 = -t(X)%*%(diag(n)*apply(V*weight,2,sum))%*%X
    log.gradtau = (rank)/(2*tau) - diag( eta%*%Q.s%*%t(eta) )/2
    log.gradtau2 = -rank/(2*tau^2)

    # first and second derivative of MCML likelihood 
    grad1 = cbind( t(log.gradbeta), log.gradtau)
    grad2.part1 = rbind( cbind(log.gradbeta2,0), c(rep(0,dim(log.gradbeta2)[1]),sum(log.gradtau2*weight)) )
    grad2.part2 = 0

    GRAD1 = apply(grad1*weight,2,sum)
    dummy = grad1 - matrix(rep(GRAD1,numiter),numiter,byrow=T)
    for(i in 1:numiter){ grad2.part2 = grad2.part2 + dummy[i,]%*%t(dummy[i,])*weight[i] }
    GRAD2 = grad2.part1 + grad2.part2

    par.prev = c(beta,tau)
    # for numerical stability
     if( (abs(det(GRAD2)) < 1e-5) ){ par.next = par.prev }else{
     par.next = par.prev - steplen*t(GRAD1)%*%solve(GRAD2) }
     if(  par.next[p+1] < 0 ){ par.next = par.prev }
     return(par.next = par.next)
   }

  ### Step 1. Obtain MLE for beta and tau
  # this part is matched to maxim.aux1 
  
  # MLE of beta and sigmasq for given phi
  i = 0
  test <- test2 <- 1
  steplen <- 1
  curr = prev = c(solve(t(X)%*%X)%*%t(X)%*%log(Z+0.5),rank/(t(eta[1,])%*%Q.s%*%eta[1,]) )                 

  log.f = func.val(prev[1:p], prev[p+1])
  dummy = log.f - log.f.sim
  mx = max(dummy)
  log.lik.prev  = log(mean(  exp(dummy-mx)  )) + mx


  while(test>0.0000000000001  | test2 > 0 ){
    i = i + 1
    # newton raphson update
    curr = newton(prev[1:p],prev[p+1],steplen)
    
    # likelihood for given updated parameters
    log.f = func.val(curr[1:p],curr[p+1])
    dummy = log.f - log.f.sim
    mx = max(dummy)
    log.lik.next  = log(mean(  exp(dummy-mx)  )) + mx

    test2 = log.lik.next - log.lik.prev
    test <- sum( (prev- curr)^2 )

    if(test2 >0){
       log.lik.prev <- log.lik.next
       prev <- curr
       }else{ steplen <- steplen/2}
  }
  beta = curr[1:p]; tau = curr[p+1]

  ###  For given phi, update beta, sigmasq, log.lik ###
  # this part is matched to maxim.aux1 
  # log[ f(Z|beta,U,D,delta)f(delta|theta) ]  
  log.f = func.val(beta,tau)
  dummy = log.f - log.f.sim
  mx = max(dummy)
  # logliklihood for given MLE
  log.lik  = log(mean(  exp(dummy-mx)  )) + mx


  # Monte Carlo standard error for given MLE
  MCSE <- function(beta,tau){

    # necessary precomputation
    xbeta = X%*%beta
    z = matrix(rep(xbeta,numiter),numiter,byrow=T)  +  t(M.eta)
    E = V = exp(z)

    # log[ f(Z|beta,U,D,delta)f(delta|theta) ] for given previous beta and sigmasq
    log.f = func.val(beta,tau)

    # weight evaluation 
    dummy = log.f - log.f.sim
    mx = max(dummy)
    weight = exp(log.f - log.f.sim - mx)/sum( exp(log.f - log.f.sim - mx)  )
    # logliklihood for given MLE 
    log.lik  = log(mean(  exp(dummy-mx)  )) + mx  

    # first and second derivatives for beta and tau
    log.gradbeta = t(X)%*%t( matrix(rep(Z,numiter),numiter,byrow=T) - E )  
    log.gradbeta2 = -t(X)%*%(diag(n)*apply(V*weight,2,sum))%*%X
    log.gradtau = (rank)/(2*tau) - diag( eta%*%Q.s%*%t(eta) )/2
    log.gradtau2 = -rank/(2*tau^2)

    # first and second derivative of MCML likelihood 
    grad1 = cbind( t(log.gradbeta), log.gradtau)
    grad2.part1 = rbind( cbind(log.gradbeta2,0), c(rep(0,dim(log.gradbeta2)[1]),sum(log.gradtau2*weight)) )
    grad2.part2 = 0

    GRAD1 = apply(grad1*weight,2,sum)
    dummy = grad1 - matrix(rep(GRAD1,numiter),numiter,byrow=T)
    for(i in 1:numiter){ grad2.part2 = grad2.part2 + dummy[i,]%*%t(dummy[i,])*weight[i] }
    GRAD2 = grad2.part1 + grad2.part2

    # for numerical stability
    if( (abs(det(GRAD2)) < 1e-5) ){ se = rep(NA,p+1); mcse = rep(NA,p+1) }else{        
    # Sampling error 
    Uhat = GRAD2
    se  = sqrt(diag(solve(-GRAD2)))

    # Monte Carlo error 
    denom = 0 
    for(i in 1:numiter){ denom = denom +  grad1[i,]%*%t(grad1[i,])*exp( 2*(log.f-log.f.sim) - max( 2*(log.f-log.f.sim) ) )[i] }
    denom = denom*exp( max( 2*(log.f-log.f.sim) ) )
    num = 2*(log( sum( exp(log.f-log.f.sim-max(log.f-log.f.sim)) ) ) + max(log.f-log.f.sim) )
    Vhat = numiter*denom/exp(num)

    mcse = sqrt(  diag( solve(Uhat)%*%Vhat%*%solve(Uhat)   ) )/sqrt(numiter)
     }
   return(list(se=se, mcse = mcse))
   }
   errors = MCSE(beta,tau)
   se = errors$se; mcse = errors$mcse

  runtime=proc.time() - ptm
  cat("runtime", "\n")  
  print(runtime)
  return(list(beta = beta, tau = tau, log.lik = log.lik, se = se, mcse = mcse))
}


##########   Step 3. Sequential MCML with stopping criteria ##########   
poi_gmrf_pSeqMCML <- function(O=obs, X, A, maxiter1, essCriteria1, maxiter2, essCriteria2, outerstop = outerstop, starting=starting, tuning=tuning, rank = rank){

  ptm <- proc.time()
  p = dim(X)[2]
  epsilon=outerstop[["epsilon"]]; maxouter = outerstop[["maxouter"]]

  stopping1 = c("maxiter" = maxiter1,"essCriteria"=essCriteria1)
  stopping2 = c("maxiter" = maxiter2,"essCriteria"=essCriteria2)

  i = 0; bound = 100; burnin = 15
  BETA = matrix(NA,maxouter,p)
  TAU = rep(NA,maxouter)
  LIK = rep(NA,maxouter)
  
  while( (bound >  epsilon) &  (i < maxouter) ){

      i = i + 1
      print(i)
      # fast search of importance function  
      mcmc.output  = poi_gmrf_pIS(O=Z, X=X, A=A, stopping = stopping1, starting=starting, tuning=tuning, rank=rank)
      res = poi_gmrf_pLikfit(mcmc.output) 

      LIK[i] = res$log.lik
      BETA[i,] = res$beta
      TAU[i] = res$tau

      # update importance function 
      starting$beta = res$beta
      starting$tau = res$tau
      starting$w = mcmc.output$w.params[dim( mcmc.output$w.params )[1],]

      if( (i >= 10+burnin ) ){  bound = bm(LIK[burnin:i])$est + bm(LIK[burnin:i])$se*qnorm(1-0.05) } 
      }


  # Conduct MCML with good importance function
  mcmc.output  = poi_gmrf_pIS(Z, X=X, A=A, stopping = stopping2, starting=starting, tuning=tuning, rank=rank)
  res = poi_gmrf_pLikfit(mcmc.output) 
  runtime = proc.time() - ptm
  cat("runtime", "\n")  
  print(runtime)
  beta = res$beta; tau = res$tau; log.lik = res$log.lik; se = res$se;  mcse = res$mcse
  
  return(list(run.time=runtime, eta.params = mcmc.output$eta.params, w.params = mcmc.output$w.params, BETA = BETA, TAU = TAU, LIK = LIK, beta = beta, tau = tau, log.lik= log.lik, se = se, mcse=mcse))
}

