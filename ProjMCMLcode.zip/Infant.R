rm(list=ls())
source("poiDiscreteMCMLoffsetsource.R")


##### Simulate the count data #####
library(ngspatial)
library(MASS)
data(infant)
infant$low_weight = infant$low_weight / infant$births
attach(infant)
Z = deaths
X = cbind(1, low_weight, black, hispanic, gini, affluence, stability)
data(A)

# tuning for running algorithms 
linmod <- glm(Z~X-1+ offset(log(births)),family="poisson") # Find starting values
starting <- list("beta"=coef(linmod),"tau"=1/var(linmod$residuals)) 
starting


tuning   <- list("beta"=c(sqrt(diag(vcov(linmod)))),"tau"=0.1,"w"=0.1) # set tuning parameters
outerstop <- c("epsilon" = 0.5,"maxouter"=40)    # stopping rule of outer loops
maxiter1 = 2e4; essCriteria1=3                   # stopping rule for finding importance function
maxiter2 = 1e5; essCriteria2=20                  # stopping rule for MCMLE at last iteration

stopping = c("maxiter" = maxiter2,"essCriteria"=essCriteria2)
#mcmc.output <- poi_gmrf_pIS(O=Z, X, A, stopping=stopping, starting=starting, tuning=tuning, rank = 50)
#res = poi_gmrf_pLikfit(mcmc.output)



set.seed(2)
result = poi_gmrf_pSeqMCML(O=Z, X, offset =log(births), A, maxiter1, essCriteria1, maxiter2, essCriteria2, outerstop = outerstop, starting=starting, tuning=tuning, rank = 50)

save(result,file="Infant.RData")

