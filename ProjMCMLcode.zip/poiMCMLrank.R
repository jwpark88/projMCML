rm(list=ls())
source("poiMCMLsource.R")

##########   Step 0. Poisson data simulation ##########   

set.seed(3)
p.true=c(2.5,1,0.2) # nu,sigma^2,range
beta.true <- c(1,1) # beta values
n = 1000      # num of data points 
n.pred = 400 # 400 predicted points
covfn<-covfndef(p.true[1]) # define the covariance function

set.seed(12)
coords.all<- matrix(runif((n+n.pred)*2),ncol=2,nrow=n+n.pred) # simulate data locations
X.all <- matrix(runif((n+n.pred)*2),ncol=2,nrow=(n+n.pred))

dist.all <- rdist(coords.all,coords.all) # compute distance matrix
V.all <- p.true[2]*covfn(dist.all,p.true[3]) # compute covariance matrix
r.e.all <- rmvn(1,rep(0,nrow(coords.all)),V.all) # simulate random effects

lambda.all <- exp(X.all%*%beta.true+r.e.all) # conditional expection for Poisson process
Z.all <- rpois(length(lambda.all), lambda.all) # simulate Poisson observations

# observed data 
coords<- coords.all[1:n,] # simulate data locations
X <- X.all[1:n,]

dist <- dist.all[1:n,1:n] # compute distance matrix
V <- V.all[1:n,1:n] # compute covariance matrix
r.e <- r.e.all[1:n] # simulate random effects

lambda <- lambda.all[1:n] # conditional expection for Poisson process
Z <- Z.all[1:n] # simulate Poisson observations

# predicted data
preds <- coords.all[(n+1):(n+n.pred),]
r.e.pred <- r.e.all[(n+1):(n+n.pred)]

##########   Step 1. Fit fast MCML    ##########   

# tuning for running algorithms 
linmod <- glm(Z~X-1,family="poisson") # Find starting values
starting <- list("beta"=coef(linmod),"s2"=var( log(Z+0.5) - X%*%coef(linmod) ),"phi"=summary(as.numeric(dist))[2]) 
starting

tuning   <- list("beta"=c(sqrt(diag(vcov(linmod)))),"s2"=0.1,"phi"=0.01,"w"=0.01) # set tuning parameters
outerstop <- c("epsilon" = 0.5,"maxouter"=40)    # stopping rule of outer loops
maxiter1 = 2e4; essCriteria1=3                   # stopping rule for finding importance function
maxiter2 = 1e5; essCriteria2=20                  # stopping rule for MCMLE at last iteration

set.seed(2)
result25 = poi_gp_rpSeqMCML(O=Z,coords=coords,X, covfn = covfn, maxiter1, essCriteria1, maxiter2, essCriteria2, outerstop = outerstop, nu=2.5, starting=starting, tuning=tuning, rank = 25, mul=2)
phi25 = result25$phi
sigmasq25 = result25$sigmasq
beta25 = result25$beta
U251 <- result25$U;rank = result25$rank
w25 = result25$w.params[dim( result25$w.params )[1],]
PHI25 = result25$PHI
SIGMASQ25 = result25$SIGMASQ
BETA25 = result25$BETA
LIK25 = result25$LIK
se25 = result25$se
mcse25 = result25$mcse

set.seed(2)
result50 = poi_gp_rpSeqMCML(O=Z,coords=coords,X, covfn = covfn, maxiter1, essCriteria1, maxiter2, essCriteria2, outerstop = outerstop, nu=2.5, starting=starting, tuning=tuning, rank = 50, mul=2)
phi50 = result50$phi
sigmasq50 = result50$sigmasq
beta50 = result50$beta
U501 <- result50$U;rank = result50$rank
w50 = result50$w.params[dim( result50$w.params )[1],]
PHI50 = result50$PHI
SIGMASQ50 = result50$SIGMASQ
BETA50 = result50$BETA
LIK50 = result50$LIK
se50 = result50$se
mcse50 = result50$mcse

set.seed(2)
result75 = poi_gp_rpSeqMCML(O=Z,coords=coords,X, covfn = covfn, maxiter1, essCriteria1, maxiter2, essCriteria2, outerstop = outerstop, nu=2.5, starting=starting, tuning=tuning, rank = 75, mul=2)
phi75 = result75$phi
sigmasq75 = result75$sigmasq
beta75 = result75$beta
U751 <- result75$U;rank = result75$rank
w75 = result75$w.params[dim( result75$w.params )[1],]
PHI75 = result75$PHI
SIGMASQ75 = result75$SIGMASQ
BETA75 = result75$BETA
LIK75 = result75$LIK
se75 = result75$se
mcse75 = result75$mcse

set.seed(2)
result100 = poi_gp_rpSeqMCML(O=Z,coords=coords,X, covfn = covfn, maxiter1, essCriteria1, maxiter2, essCriteria2, outerstop = outerstop, nu=2.5, starting=starting, tuning=tuning, rank = 100, mul=2)
phi100 = result100$phi
sigmasq100 = result100$sigmasq
beta100 = result100$beta
U1001 <- result100$U;rank = result100$rank
w100 = result100$w.params[dim( result100$w.params )[1],]
PHI100 = result100$PHI
SIGMASQ100 = result100$SIGMASQ
BETA100 = result100$BETA
LIK100 = result100$LIK
se100 = result100$se
mcse100 = result100$mcse


save( phi25, sigmasq25, beta25, U251, w25, PHI25, SIGMASQ25, BETA25, LIK25, se25, mcse25,
          phi50, sigmasq50, beta50, U501, w50, PHI50, SIGMASQ50, BETA50, LIK50, se50, mcse50,
          phi75, sigmasq75, beta75, U751, w75, PHI75, SIGMASQ75, BETA75, LIK75, se75, mcse75,  
          phi100, sigmasq100, beta100, U1001, w100, PHI100, SIGMASQ100, BETA100, LIK100, se100, mcse100, 
          file="poiMCMLrank.RData")


#pred.est = gp_rpPrediction(result,coords,preds) 

#pdf("PoiPred.pdf")
#par(mfrow=c(2,2))
#plotRef(coords, r.e,main="hi")
#legend.col(col = tim.colors(8), lev = seq(min(r.e),max(r.e),length=10))
#mtext("Simulated Random Effects", side = 3, line = 1, adj = 0, cex = 1.1)

#plotRef(coords,result$w.params[dim(result$w.params)[1],])
#legend.col(col = tim.colors(8), lev = seq(min(result$w.params[dim(result$w.params)[1],]),max(result$w.params[dim(result$w.params)[1],]),length=10))
#mtext("Estimated Random Effects", side = 3, line = 1, adj = 0, cex = 1.1)

#plotRef(preds,r.e.pred)
#legend.col(col = tim.colors(8), lev = seq(min(r.e.pred),max(r.e.pred),length=10))
#mtext("Simulated Random Effects", side = 3, line = 1, adj = 0, cex = 1.1)

#plotRef(preds,pred.est)
#legend.col(col = tim.colors(8), lev = seq(min(r.e.pred),max(r.e.pred),length=10))
#mtext("Predicted Random Effects", side = 3, line = 1, adj = 0, cex = 1.1)
#dev.off()


