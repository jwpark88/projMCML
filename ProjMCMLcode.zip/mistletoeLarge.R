
##########   Step 0. Load source code and datasets   ##########   
rm(list=ls())
source("binaryMCMLsource.R") 
data=read.csv("mistletoe.csv")
head(data)
N <- dim(data)[1]

# randomly select 2800 points (2000 estimation/ 800 prediction)
set.seed(3)
n = 4000
n.pred = 1000
id = sample(1:N,n+n.pred)

Z.all <- data[id,16]                     # infected.mndnr is response  
coords.all <- data[id,14:15]             # UTMs coordinates
dist.all <- rdist(coords.all,coords.all) # compute distance matrix
#plotRef(coords.all, Z.all)

# observed data 
coords <- coords.all[1:n,] # simulate data locations
dist <- dist.all[1:n,1:n] # compute distance matrix
Z <- Z.all[1:n]

# predicted data
preds <- coords.all[(n+1):(n+n.pred),]
Z.preds <- Z.all[(n+1):(n+n.pred)]
covfn<-covfndef(2.5) # define the covariance function


# Design matrix (coordinats and covariates), age, basal area, height, volume
X.all <- as.matrix(  cbind(coords.all,data[id,c(7,8,10,11)])  )
X <- X.all[1:n,]
Xpreds <- X.all[(n+1):(n+n.pred),]


##########   Step 1. Fit fast MCML    ##########   
# tuning for running algorithms 
linmod <- glm(Z~X-1,family="binomial") # Find starting values
starting <- list("beta"=coef(linmod),"s2"=var(linmod$residuals),"phi"=summary(as.numeric(dist))[2]) 
starting

tuning   <- list("beta"=c(sqrt(diag(vcov(linmod)))),"s2"=0.1,"phi"=0.01,"w"=0.05) # set tuning parameters
outerstop <- c("epsilon" = 0.5,"maxouter"=40)    # stopping rule of outer loops
maxiter1 = 2e4; essCriteria1=3                   # stopping rule for finding importance function
maxiter2 = 1e5; essCriteria2=20                  # stopping rule for MCMLE at last iteration

#stopping = c("maxiter" = maxiter1,"essCriteria"=essCriteria1)
#mcmc.output <- binary_gp_rpIS(O=Z,coords=X,X, covfn = covfn, stopping=stopping, nu=2.5, starting=starting, tuning=tuning, rank = 50,mul=2)




set.seed(7)
result = binary_gp_rpSeqMCML(O=Z,coords=coords,X, covfn = covfn, maxiter1, essCriteria1, maxiter2, essCriteria2, outerstop = outerstop, nu=2.5, starting=starting, tuning=tuning, rank = 50, mul=2)



set.seed(4)
#pred.est = gp_rpPrediction(result,coords,preds) 




#W = result$w.params[dim(result$w.params)[1],]
#p.est = exp(X%*%result$beta + W)/(1+exp(X%*%result$beta + W))
#Z.est = sapply(p.est, function(x) sample(0:1, 1, prob = c(1-x, x)))

#p.pred = exp(Xpreds%*%result$beta + pred.est)/(1+exp(Xpreds%*%result$beta + pred.est))
#Z.pred = sapply(p.pred, function(x) sample(0:1, 1, prob = c(1-x, x)))

#par(mfrow=c(2,2))
#plotRef(coords,Z)
#plotRef(coords,Z.est)
#plotRef(preds,Z.preds)
#plotRef(preds,Z.pred)





save(  result, file="mistletoeLarge.RData")




